//charbst.h
#ifndef CHARBST_H
#define CHARBST_H

// BST interface
int search(char d);
int insert(char d);
int deleteByMerging(char d);
void inorder(void);
int isEmpty();
void display();

void preorder();
void postorder();
void levelOrder();
int getSize();
void clear();
int getNumOfLeaves();

#endif

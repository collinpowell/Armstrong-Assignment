// MainTest.cpp  : This file contains the 'main' function. Program execution begins and ends there.
//
#include "charbst.h"

#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>

int main()
{
	int ok;
	char ans, d;
	//Display Instructions
	printf("Menu driven pogram to test a BST that conttains characters\n");

	do {
		//display menu
		printf("\nMenu options\n");
		printf("\ti: Insert Data\n");
		printf("\td: Delete Data by Merging\n");
		printf("\ts: Search Tree\n");
		printf("\tp: Print Tree\n");
		printf("\tt: Inorder Traverse Tree\n");
		printf("\tq: Quit Program\n");
		printf("Please enter choice : ");
		scanf("\n%c", &ans);  //read first non-whitespace char
		switch (ans)
		{
			case 'i':	printf("What character do you wist to insert: ");
						scanf("\n%c", &d);
						ok = insert(d);
						if (!ok){
							printf("The character %c is already in tree\n", d);
						}
						break;

			case 'd':	printf("What character do you wish to delete: ");
						scanf("\n%c", &d);
						ok = deleteByMerging(d);
						if (!ok){
							printf("The character %c is not in the tree\n", d);
						}
						break;

			case 's':	printf("What character do you wist to find: ");
						scanf("\n%c", &d);
						ok = search(d);
						if (ok){
							printf("The character %c is in the tree\n", d);
						}
						else {
							printf("The character %c is not in the tree\n", d);
						}
						break;
            case 'p':   printf("\n");
						if (isEmpty()){
							printf("The tree is empty.\n");
						}
						else {
							display();
						}
						break;
            case 't':   printf("In order Traversal visits [");
                        inorder();
                        printf("] in that order\n");
                        break;
            default:    break;
		}
	} while(ans != 'q');
	return 0;
}

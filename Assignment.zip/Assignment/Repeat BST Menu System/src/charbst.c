// M.Gill 2023
#include "charbst.h"
#include <stdio.h>
#include <stdlib.h>

#define TRUE 1
#define FALSE 0
static int treeSize = 0;

//Tree node struct template
typedef struct BSTNodeT
{
	char data;
	struct BSTNodeT *left;
	struct BSTNodeT *right;
} BSTNode;

//define and initialise root
static BSTNode *root = 0;

// Define QueueNode and Queue structures here
typedef struct QueueNode {
    BSTNode* data;
    struct QueueNode* next;
} QueueNode;

typedef struct {
    QueueNode* front;
    QueueNode* rear;
} Queue;

Queue* createQueue() {
    Queue* queue = (Queue*)malloc(sizeof(Queue));
    if (queue == NULL) {
        exit(EXIT_FAILURE);
    }
    queue->front = NULL;
    queue->rear = NULL;
    return queue;
}

int pIsEmpty(Queue* queue) {
    return (queue->front == NULL);
}

void enqueue(Queue* queue, BSTNode* data) {
    QueueNode* newNode = (QueueNode*)malloc(sizeof(QueueNode));
    if (newNode == NULL) {
        exit(EXIT_FAILURE);
    }
    newNode->data = data;
    newNode->next = NULL;

    if (queue->rear == NULL) {
        queue->front = newNode;
        queue->rear = newNode;
    } else {
        queue->rear->next = newNode;
        queue->rear = newNode;
    }
}

BSTNode* dequeue(Queue* queue) {
    if (pIsEmpty(queue)) {
        return NULL;
    }

    QueueNode* temp = queue->front;
    BSTNode* data = temp->data;
    queue->front = temp->next;

    if (queue->front == NULL) {
        queue->rear = NULL;
    }

    free(temp);
    return data;
}

//declare utility functions
static void inorderR(BSTNode *p );  //recursive function for inorder traversal
static void displayR(BSTNode* p, int level);  //recursive part of display function
static void visit(char d);  //Just prints

//implement functions
int search(char d)
{
	BSTNode *p = root;

	while (p)
	{
		if (d == p->data)
			return TRUE;
		else if (d < p->data)
			p = p->left;
		else // (d > p->data)
			p = p->right;

	}
	return FALSE;
}

int insert(char d)
{
	BSTNode *p = root, *tmp;

	if (p)
	{
		while (1)
		{
			if (d == p->data)
				return FALSE;
			else if (d < p->data)
			{
				if (p->left)
					p = p->left;
				else
				{
					tmp = p->left = (BSTNode*)malloc(sizeof(BSTNode));
					if (tmp == 0)
					{
						printf("malloc error\n");
						exit(1);
					}
					tmp->data = d;  //Place data
					tmp->left = tmp->right = 0;  //Node is a leaf
					return TRUE;
				}
			}
			else // (d > p->data)
			{
				if (p->right)
					p = p->right;
				else
				{
					tmp = p->right = (BSTNode*)malloc(sizeof(BSTNode));
					if (tmp == 0)
					{
						printf("malloc error\n");
						exit(1);
					}
					tmp->data = d;  //Place data
					tmp->left = tmp->right = 0; //Node is a leaf
					return TRUE;
				}
			}
		}
	}
	else
	{
		root = (BSTNode*)malloc(sizeof(BSTNode));
		if (root == 0)
		{
			printf("malloc error\n");
			exit(1);
		}
		root->data = d;  //Place data
		root->left = root->right = 0; //Node is a leaf
		return TRUE;
	}

}

int deleteByMerging(char d)
{
	BSTNode *node = root, *prev = 0;

	//search for node to be deleted
	while (node)
	{
		if (node->data == d)
			break;
		prev = node;
		if (node->data < d)
			node = node->right;
		else
			node = node->left;
	}

	if (!node)
		return FALSE;  //data not in tree
	else //data found
	{
		//delete node
		BSTNode *tmp = node;

		if (!(node->right))  //no right child or no child
			node = node->left;
		else if (!(node->left)) // no left child but right child
			node = node->right;
		else
		{
			//delete node with two children
			tmp = node->left;  // move left

			while (tmp->right)
				tmp = tmp->right;  // keep moving right

			tmp->right = node->right; //Make link

			tmp = node; //restore tmp to node to be removed
			node = node->left;
		}

		// link up parent of deleted node
		if (root == tmp)
			root = node;
		else if (prev->left == tmp)
			prev->left = node;
		else
			prev->right = node;

		free(tmp);  // destroy deleted node

		return TRUE;  //node deleted
	}


}

void inorder(void)
{
	inorderR(root);  // recursive call starting from root
}

int isEmpty()
{
	return (root == 0);
}


static void inorderR(BSTNode* p) {
	if (p)
	{
		inorderR(p->left);
		visit(p->data);
		inorderR(p->right);
	}

}

static void visit(char d)  //Just prints
{
	printf("%c ",d);
}

void display()
{
	displayR(root, 0);
}

static void displayR(BSTNode* p, int level)   //recursive part of display function
{
	if (p)
	{
		displayR(p->right, level+1);          // display right subtree
		printf("%*c%c",level*5,' ',p->data);  // display data preceded by (level multiplied by 5) spaces
		if (p->left)                          // display symbols indicating children
		{									  //
			if (p->right)					  //
				printf("\xB4\n");			  //
			else //no (p->right)			  //
				printf("\xBf\n");			  //
		}					                  //
		else //no (p->left)					  //
		{					                  //
			if (p->right)					  //
				printf("\xD9\n");			  //
			else //no (p->right)			  //
				printf("\n");				  //
		}
		displayR(p->left, level+1);			  // display left subtree
	}
}








static void preorderR(BSTNode* root) {
    if (root == NULL) {
        return;
    }
    printf("%c ", root->data);
    preorderR(root->left);
    preorderR(root->right);
}

static void postorderR(BSTNode* root) {
    if (root == NULL) {
        return;
    }
    postorderR(root->left);
    postorderR(root->right);
    printf("%c ", root->data);
}

void preorder() {
    preorderR(root);
    printf("\n");
}

void postorder() {
    postorderR(root);
    printf("\n");
}

int getNumOfLeavesR(BSTNode* root) {
    if (root == NULL) {
        return 0;
    }
    if (root->left == NULL && root->right == NULL) {
        return 1;
    }
    return getNumOfLeavesR(root->left) + getNumOfLeavesR(root->right);
}

int getNumOfLeaves() {
    return getNumOfLeavesR(root);
}

void clearR(BSTNode* root) {
    if (root == NULL) {
        return;
    }
    clearR(root->left);
    clearR(root->right);
    free(root);
}

void clear() {
    BSTNode *p = root;
    clearR(p);
    root = NULL;
    treeSize = 0;
}

void levelOrder(BSTNode* root) {
    if (root == NULL) {
        return;
    }

    QueueNode* queue = createQueue();
    enqueue(queue, root);

    while (!pIsEmpty(queue)) {
        BSTNode* current = dequeue(queue);
        printf("%c ", current->data);

        if (current->left != NULL) {
            enqueue(queue, current->left);
        }
        if (current->right != NULL) {
            enqueue(queue, current->right);
        }
    }

    printf("\n");
}

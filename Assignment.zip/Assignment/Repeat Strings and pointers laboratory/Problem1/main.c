#include <stdio.h>
#include <ctype.h>  // Include the ctype.h library for character handling functions
#include <string.h> // Include the string.h library for string handling functions

void changeChars(char *str)
{          // Define a function called changeChars that takes a string as an argument
    int i; // Declare an integer variable i
    for (i = 0; i < strlen(str); i++)
    { // Iterate over each character in the string using a for loop
        if (islower(str[i]))
        {                             // Check if the character is lowercase using the islower function
            str[i] = toupper(str[i]); // Convert the character to uppercase using the toupper function
        }
        else if (isupper(str[i]))
        {                             // Check if the character is uppercase using the isupper function
            str[i] = tolower(str[i]); // Convert the character to lowercase using the tolower function
        }
    }
}

int main()
{
    char str[30] = "HellO";
    changeChars(str);
    printf("%s\n", str);
    // will display “hELLo” on the console.
    return 0;
}
#include <stdio.h>
#include <string.h>

#define MAX_SIZE 1000

void replace(char *str, char **oldSubStrings, char **newSubStrings, int numSubStrings)
{
    char *pos;
    int i;
    for (i = 0; i < numSubStrings; i++)
    {
        while ((pos = strstr(str, oldSubStrings[i])) != NULL)
        {
            memmove(pos + strlen(newSubStrings[i]), pos + strlen(oldSubStrings[i]), strlen(pos + strlen(oldSubStrings[i])) + 1);
            memcpy(pos, newSubStrings[i], strlen(newSubStrings[i]));
        }
    }
}

// iterating through substrings
// Checking those sub strings are inside our string variable
// Replace with newSubString

int main()
{
    FILE *fp;
    char str[MAX_SIZE];
    char *oldSubStrings[] = {"text is", "replaced", "array"};
    char *newSubStrings[] = {"strings are", "modified", "list"};
    int numSubStrings = 3;

    fp = fopen("file.txt", "r");
    if (fp == NULL)
    {
        printf("Error opening file\n");
        return -1;
    }

    // ['h','e','l','l','o','\0']

    fgets(str, MAX_SIZE, fp);
    if (strlen(str) == MAX_SIZE - 1 && str[MAX_SIZE - 2] != '\n')
    {
        printf("Error: string too long\n");
        return -1;
    }

    replace(str, oldSubStrings, newSubStrings, numSubStrings);

    printf("%s\n", str);

    fclose(fp);
}

#include <stdio.h>
#include "cplx.h"
int main(void)
{
	/**cpx c1,c2,c3;     // declare three complex numbers

	// read c1 and c2 from the user
	c1 = getcplx();
	c2 = getcplx();

	// add them
	c3 = dividecplx(c1,c2);

	// display answer
	printcplx(c3);**/

	cpx numerator1 = {
        real: 3.14,
        imag: 5.0
	};

	cpx numerator2 = {
        real: 1.0,
        imag: 1.0
	};

	cpx numerator3 = {
        real: 0,
        imag: 2
	};

	cpx denominator = {
        real: 3.2,
        imag: -3
	};

	cpx result = dividecplx(subtractcplx(multipycplx(numerator1,numerator2) ,numerator3),denominator);

	printf("\n");

	// display answer
	printcplx(result);

	return 0;
}

//cplx.h
#ifndef CPLX_H
#define CPLX_H

typedef struct	/* Template for a complex number */
{
	double real;
	double imag;
} cpx;

// function prototypes
cpx getcplx();
cpx addcplx(cpx num1, cpx num2);
cpx subtractcplx(cpx num1, cpx num2);
cpx multipycplx(cpx num1, cpx num2);
cpx dividecplx(cpx num1, cpx num2);
void printcplx( cpx num);

#endif /* CPLX_H */


//cplx.c
#include <stdio.h>
#include "cplx.h"

cpx getcplx() // Function to read a complex number from the kbrd
{
   cpx num;
   printf("Please input a complex number\nReal part : ");
   scanf("%lf",&num.real);
   printf("Imaginary part : ");
   scanf("%lf",&num.imag);

   return num;
}
//***************************************

cpx addcplx(cpx num1, cpx num2)  // Function to add two cpx numbers and return their sum
{

 cpx num;

   num.real=num1.real + num2.real ;
   num.imag=num1.imag + num2.imag;

   return num;
}

/***************************************/

//***************************************

cpx subtractcplx(cpx num1, cpx num2)  // Function to subtract two cpx numbers and return their sum
{

 cpx num;

   num.real=num1.real - num2.real ;
   num.imag=num1.imag - num2.imag;

   return num;
}

/***************************************/

//***************************************

cpx multipycplx(cpx num1, cpx num2)  // Function to multiply two cpx numbers and return their sum
{

 cpx num;

   num.real=(num1.real * num2.real)+(-1*num1.imag * num2.imag);
   num.imag=(num1.real * num2.imag)+(num1.imag * num2.real);

   return num;
}

/***************************************/

//***************************************

cpx dividecplx(cpx num1, cpx num2)  // Function to divide two cpx numbers and return their sum
{

 cpx num;
   double numSquare = (num2.real*num2.real) + (num2.imag*num2.imag);
   num.real= ((num1.real * num2.real) + (num1.imag * num2.imag))/numSquare;
   num.imag=((num1.imag * num2.real) - (num1.real * num2.imag))/numSquare;

   return num;
}

/***************************************/

void printcplx(cpx num) // Function to output a cpx number
{
  printf("%lf%+lfj", num.real, num.imag);
}


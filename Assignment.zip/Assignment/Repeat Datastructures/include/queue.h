#ifndef QUEUE_H
#define QUEUE_H

void qPush(int item);
void qPop();
void printQueue();

#endif // QUEUE_H

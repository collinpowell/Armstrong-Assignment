// stack.h
// Stack Header File

#ifndef STACK_H
#define STACK_H
void sPush(int value);
int sPop(void);
int sIsEmpty(void);
int sGetSize(void);
#endif //STACK_H

#include "queue.h"
#include <stdio.h>
#include <stdlib.h>

struct node {
    int data;
    struct node* next;
};

struct node* head;
struct node* tail;
// Insertion at the tail of the queue
void qPush(int item) {
    struct node* temp = (struct node*)malloc(sizeof(struct node)); // Allocate memory for a new node
    if(temp == NULL){
        printf("Stack overflow\n");
        exit(1);
    }else{
        temp->data = item; // Assign the data to the new node
        temp->next = NULL; // Set the next pointer of the new node to NULL
        if (head == NULL && tail == NULL) { // If the queue is empty
            head = tail = temp; // Set both head and tail pointers to the new node
            return;
        }
        tail->next = temp; // Set the next pointer of the current tail to the new node
        tail = temp; // Set the tail pointer to the new node
    }
}

// Removal from the head of the queue
void qPop() {
    struct node* temp = head; // Create a temporary pointer to head
    if (head == NULL) {
        printf("Stack underflow\n");
        exit(1);
        return;
    } // If queue is empty, return
    if (head == tail) { // If there is only one element in the queue
        head = tail = NULL; // Set both head and tail pointers to NULL
    } else {
        head = head->next; // Set head pointer to next element in queue
    }
    free(temp); // Free memory allocated for previous head element
}

// Printing the queue
void printQueue() {
    struct node* temp = head; // Create a temporary pointer to head
    while (temp != NULL) { // Traverse through all elements in queue until end is reached (NULL)
        printf("%d ", temp->data); // Print data of current element
        temp = temp->next; // Move to next element in queue
    }
}

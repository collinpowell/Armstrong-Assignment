// stack.c
// Stack implementation file

#include "stack.h"
#include <stdlib.h>
#include <stdio.h>

// define the template for a node in the stack
typedef struct NodeT
{
    int data;
    struct NodeT *next;
} Node;

static Node *sHead = NULL; // The stack is initially empty

void sPush(int value)
{
    Node *temp;

    // get a new node
    temp = (Node *)malloc(sizeof(Node));
    if (temp == NULL) // Simple check for a stack overflow
    {
        printf("Stack overflow\n");
        exit(1);
    }
    else
    {
        // Place value into the node and add to list
        temp->data = value;
        temp->next = sHead;
        sHead = temp;
    }
}

int sPop(void)
{
    Node *temp = NULL;
    int value = 0;

    if (sHead == NULL) // Simple check for an empty stack
    {
        printf("Stack underflow\n");
        exit(1);
    }
    else
    {
        // get the value at the top of the list
        value = sHead->data;

        // remove the top entry from the list
        temp = sHead;
        sHead = sHead->next;
        free(temp);
    }

    // return the value
    return value;
}

// Printing the stack
void printStack() {
    Node *temp= sHead; // Create a temporary pointer to top
    while (temp != NULL) { // Traverse through all elements in stack until end is reached (NULL)
        printf("%d ", temp->data); // Print data of current element
        temp = temp->next; // Move to next element in stack
    }
}

// Check if stack is empty
int sIsEmpty() {
    if (sHead == NULL) { // If stack is empty
        return 1; // Return TRUE (1)
    } else { // If stack is not empty
        return 0; // Return FALSE (0)
    }
}

// Count number of nodes on stack
int sGetSize() {
    int count = 0; // Initialize count variable to 0
     Node *temp= sHead; // Create a temporary pointer to top
    while (temp != NULL) { // Traverse through all elements in stack until end is reached (NULL)
        count++; // Increment count variable for each element in stack
        temp = temp->next; // Move to next element in stack
    }
    return count; // Return count variable after all elements have been counted
}

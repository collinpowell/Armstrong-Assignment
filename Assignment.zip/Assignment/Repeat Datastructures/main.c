// A linked list stack

#include "stack.h"
#include "queue.h"
#include <stdio.h>

int main(void)
{
    //FIFO
    qPush(2);
    qPush(4);
    qPush(6);
    qPush(8);
    qPop();
    printQueue();
    printf("\n");

    // FILO
    printf("\nEmpty? %d", sIsEmpty());
	printf("Size: %d\n", sGetSize());
	sPush(10);
	printf("\nEmpty? %d", sIsEmpty());
	printf("Size: %d\n", sGetSize());
	sPush(25);
	printf("\nEmpty? %d", sIsEmpty());
	printf("Size: %d\n", sGetSize());
	sPush(15);
	printf("\nEmpty? %d", sIsEmpty());
	printf("Size: %d\n", sGetSize());

	// will output 15 25 10 Stack underflow
	printf("%d", sPop());
	printf("\nEmpty? %d", sIsEmpty());
	printf("Size: %d\n", sGetSize());
	printf(" %d", sPop());
	printf("\nEmpty? %d", sIsEmpty());
	printf("Size: %d\n", sGetSize());
	printf(" %d ", sPop());
	printf("\nEmpty? %d", sIsEmpty());
	printf("Size: %d\n", sGetSize());
	sPop();


	return 0;
}
